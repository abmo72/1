package com.cti.dice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
