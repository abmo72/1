package com.cti.magic_8_ball

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
